#!/usr/bin/python
import sys
import json
import time
import requests
import xlsxwriter

def checkResponse(r):
    """
	Quick logic to check the http response code.

	Parameters:
		r = http response object.
	"""

    acceptedResponses = [200, 201, 203, 204]
    if not r.status_code in acceptedResponses:
        print "STATUS: {status} ".format(status=r.status_code)
        print "ERROR: " + r.text
        sys.exit(r.status_code)


def authenticate(host, user, password, tenant):
    """
	Function that will authenticate a user and build.

	Parameters:
		host = vRA Appliance fqdn.
		user = user account with access to the vRA portal.
		passowrd = valid password for above user.
		tenant = tenant for the user.
	"""

    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    payload = {"username": user, "password": password, "tenant": tenant}
    url = 'https://' + host + '/identity/api/tokens'
    r = requests.post(url=url,
                      data=json.dumps(payload),
                      headers=headers,
                      verify=False)
    checkResponse(r)
    response = r.json()

    usr_token = 'Bearer ' + response['id']

    return usr_token

def getResourceByBusinessGroup(host, token, name, limit=100, show='json'):
        """
        Function that will get all vRA resources running
        for a specific Business group
        Parameters:
            show = return data as a table or json object
            name = name of the vRA resource.
        """
        url = "https://{host}/catalog-service/api/consumer/resources".format(host=host)
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': token
        }
        r = requests.get(url=url, headers=headers, verify=False)
        checkResponse(r)
        resource = r.json()
        result = resource
        if result['metadata']['totalPages'] != 1:
            page = 2  # starting on 2 since we've already got page 1's data
            while page <= result['metadata']['totalPages']:
                url = "https://{host}/catalog-service/api/consumer/resources?page={pageno}".format(host=host, pageno=page)
                next_page_result = requests.get(url=url, headers=headers, verify=False)
                next_page = next_page_result.json()
                for i in next_page['content']:
                    result['content'].append(i)
                page += 1
            return result


def main():

    host = 'ncloud.nus.edu.sg'
    tenant = 'nus-it'

    username = 'admincml'

    password = ''

    bg_name = 'NUS IT Managed Systems'

    bpstr = 'Clus'

    timestr = time.strftime("%Y%m%d")

    xlsfilename = 'vra-deployments-' + timestr + '.xlsx'

    workbook = xlsxwriter.Workbook(xlsfilename)

    worksheet = workbook.add_worksheet('Items')

    cell_format1 = workbook.add_format({'align': 'center',
                                   'valign': 'vcenter',
                                   'border': 2})

    cell_format = workbook.add_format()

    cell_format.set_border(1)

    vra_item = {}

    # Header
    header_format = workbook.add_format()

    header_format.set_bg_color('green')

    header_format.set_bold()

    header_format.set_center_across()

    header_format.set_font_color('white')

    header_format.set_border(2)

    header_format.set_bottom_color('orange')

    header_format.set_top_color('orange')

    header_format.set_left_color('orange')

    header_format.set_right_color('orange')

    worksheet.write(0, 0, 'Deployment Name', header_format)

    worksheet.write(0, 1, 'Resource Name', header_format)

    token = authenticate(host, username, password, tenant)

    r = getResourceByBusinessGroup(host, token, bg_name)

    row = 1
    for item in r['content']:
        if item['parentResourceRef']:
            if bpstr in item['parentResourceRef']['label']:
                parant_name = item['parentResourceRef']['label']
                parent_id = item['parentResourceRef']['id']
                item_list = []
                item_list.append(parant_name)
                for comp in r['content']:
                    if comp['parentResourceRef']:
                        if comp['parentResourceRef']['id'] == parent_id:
                            item_list.append(comp['name'])
                col = 0
                lsize = len(item_list[1:])
                worksheet.set_column('A:B', 70)
                worksheet.merge_range(row, 0, (row + lsize - 1), 0, item_list[0], cell_format1)
                for colum in item_list[1:]:
                    worksheet.write(row, col+1, colum, cell_format)
                    row = row +1
    workbook.close()


if __name__ == "__main__":
    main()
